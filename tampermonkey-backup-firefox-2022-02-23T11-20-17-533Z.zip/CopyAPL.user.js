// ==UserScript==
// @name         CopyAPL
// @version      1
// @namespace    http://tampermonkey.net/
// @grant        GM_xmlhttpRequest
// @grant        none
// ==/UserScript==


window.addEventListener('DOMContentLoaded', (event) => {
  document.body.innerHTML += "<button id=\"apl-execute-copy\" style=\"display:hidden\" accesskey=\"x\">⍎</button>";
  let exButton = document.getElementById("apl-execute-copy");
	exButton.addEventListener('click', function (e) {
    let request = new XMLHttpRequest();
    let code = window.getSelection().toString();
    console.log(code);
    document.body.style.cursor = "wait";
		request.open("POST", "https://tryapl.org/Exec", true);
		request.setRequestHeader("Content-Type", "application/json; charset=utf-8")
		request.send(JSON.stringify(["", 0, "", code]));
		request.onreadystatechange = function () {
			if (request.readyState === 4) {
				if (request.status === 200) {
					let result = JSON.parse(request.responseText)[3];
					result.unshift("      " + code);
          result = result.join("\n");
          navigator.clipboard.writeText(text).then(function() {
            console.log('Async: Copying to clipboard was successful!');
          }, function(err) {
            console.error('Async: Could not copy text: ', err);
          });
					
				}
			}
      document.body.style.cursor = "pointer";
		}
	});
});
