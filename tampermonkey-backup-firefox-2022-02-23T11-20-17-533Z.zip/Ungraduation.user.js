// ==UserScript==
// @name         Ungraduation
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       hyper-neutrino
// @match        https://codegolf.stackexchange.com/*
// @match        https://codegolf.meta.stackexchange.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener("DOMContentLoaded", function(event) {
        var meta = false;

        for (var x of $("link")) {
            if (x.href.startsWith("https://cdn.sstatic.net/Sites/codegolf/primary.css")) {
                x.href = "https://cdn.sstatic.net/Sites/conlang/primary.css?v=8ce811166601";
            }
            if (x.href.startsWith("https://cdn.sstatic.net/Sites/codegolfmeta/primary.css")) {
                x.href = "https://cdn.sstatic.net/Sites/conlangmeta/primary.css?v=8ce811166601";
                meta = true;
            }
        }

        $(".site-header--link")[0].innerHTML = "Programming Puzzles and Code Golf&nbsp;<span class='m14 o60 fw-normal'>" + (meta ? "Meta" : "Beta") + "</span>";
    });
})();